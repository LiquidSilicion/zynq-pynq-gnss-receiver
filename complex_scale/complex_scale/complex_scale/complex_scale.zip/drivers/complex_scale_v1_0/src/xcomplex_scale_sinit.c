// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xcomplex_scale.h"

extern XComplex_scale_Config XComplex_scale_ConfigTable[];

#ifdef SDT
XComplex_scale_Config *XComplex_scale_LookupConfig(UINTPTR BaseAddress) {
	XComplex_scale_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XComplex_scale_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XComplex_scale_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XComplex_scale_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XComplex_scale_Initialize(XComplex_scale *InstancePtr, UINTPTR BaseAddress) {
	XComplex_scale_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XComplex_scale_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XComplex_scale_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XComplex_scale_Config *XComplex_scale_LookupConfig(u16 DeviceId) {
	XComplex_scale_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCOMPLEX_SCALE_NUM_INSTANCES; Index++) {
		if (XComplex_scale_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XComplex_scale_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XComplex_scale_Initialize(XComplex_scale *InstancePtr, u16 DeviceId) {
	XComplex_scale_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XComplex_scale_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XComplex_scale_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif


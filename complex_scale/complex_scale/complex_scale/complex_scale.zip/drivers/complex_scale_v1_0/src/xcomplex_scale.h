// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XCOMPLEX_SCALE_H
#define XCOMPLEX_SCALE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcomplex_scale_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XComplex_scale_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XComplex_scale;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XComplex_scale_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XComplex_scale_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XComplex_scale_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XComplex_scale_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XComplex_scale_Initialize(XComplex_scale *InstancePtr, UINTPTR BaseAddress);
XComplex_scale_Config* XComplex_scale_LookupConfig(UINTPTR BaseAddress);
#else
int XComplex_scale_Initialize(XComplex_scale *InstancePtr, u16 DeviceId);
XComplex_scale_Config* XComplex_scale_LookupConfig(u16 DeviceId);
#endif
int XComplex_scale_CfgInitialize(XComplex_scale *InstancePtr, XComplex_scale_Config *ConfigPtr);
#else
int XComplex_scale_Initialize(XComplex_scale *InstancePtr, const char* InstanceName);
int XComplex_scale_Release(XComplex_scale *InstancePtr);
#endif

void XComplex_scale_Start(XComplex_scale *InstancePtr);
u32 XComplex_scale_IsDone(XComplex_scale *InstancePtr);
u32 XComplex_scale_IsIdle(XComplex_scale *InstancePtr);
u32 XComplex_scale_IsReady(XComplex_scale *InstancePtr);
void XComplex_scale_EnableAutoRestart(XComplex_scale *InstancePtr);
void XComplex_scale_DisableAutoRestart(XComplex_scale *InstancePtr);

void XComplex_scale_Set_num_samples(XComplex_scale *InstancePtr, u32 Data);
u32 XComplex_scale_Get_num_samples(XComplex_scale *InstancePtr);
void XComplex_scale_Set_scale_factor(XComplex_scale *InstancePtr, u32 Data);
u32 XComplex_scale_Get_scale_factor(XComplex_scale *InstancePtr);

void XComplex_scale_InterruptGlobalEnable(XComplex_scale *InstancePtr);
void XComplex_scale_InterruptGlobalDisable(XComplex_scale *InstancePtr);
void XComplex_scale_InterruptEnable(XComplex_scale *InstancePtr, u32 Mask);
void XComplex_scale_InterruptDisable(XComplex_scale *InstancePtr, u32 Mask);
void XComplex_scale_InterruptClear(XComplex_scale *InstancePtr, u32 Mask);
u32 XComplex_scale_InterruptGetEnabled(XComplex_scale *InstancePtr);
u32 XComplex_scale_InterruptGetStatus(XComplex_scale *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

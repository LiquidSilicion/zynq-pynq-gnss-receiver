// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xcomplex_scale.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XComplex_scale_CfgInitialize(XComplex_scale *InstancePtr, XComplex_scale_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XComplex_scale_Start(XComplex_scale *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XComplex_scale_IsDone(XComplex_scale *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XComplex_scale_IsIdle(XComplex_scale *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XComplex_scale_IsReady(XComplex_scale *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XComplex_scale_EnableAutoRestart(XComplex_scale *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XComplex_scale_DisableAutoRestart(XComplex_scale *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_AP_CTRL, 0);
}

void XComplex_scale_Set_num_samples(XComplex_scale *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_NUM_SAMPLES_DATA, Data);
}

u32 XComplex_scale_Get_num_samples(XComplex_scale *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_NUM_SAMPLES_DATA);
    return Data;
}

void XComplex_scale_Set_scale_factor(XComplex_scale *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_SCALE_FACTOR_DATA, Data);
}

u32 XComplex_scale_Get_scale_factor(XComplex_scale *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_SCALE_FACTOR_DATA);
    return Data;
}

void XComplex_scale_InterruptGlobalEnable(XComplex_scale *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_GIE, 1);
}

void XComplex_scale_InterruptGlobalDisable(XComplex_scale *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_GIE, 0);
}

void XComplex_scale_InterruptEnable(XComplex_scale *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_IER);
    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_IER, Register | Mask);
}

void XComplex_scale_InterruptDisable(XComplex_scale *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_IER);
    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XComplex_scale_InterruptClear(XComplex_scale *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XComplex_scale_WriteReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_ISR, Mask);
}

u32 XComplex_scale_InterruptGetEnabled(XComplex_scale *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_IER);
}

u32 XComplex_scale_InterruptGetStatus(XComplex_scale *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XComplex_scale_ReadReg(InstancePtr->Control_BaseAddress, XCOMPLEX_SCALE_CONTROL_ADDR_ISR);
}


// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xcarrier_nco.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCarrier_nco_CfgInitialize(XCarrier_nco *InstancePtr, XCarrier_nco_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCarrier_nco_Start(XCarrier_nco *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_AP_CTRL) & 0x80;
    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCarrier_nco_IsDone(XCarrier_nco *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCarrier_nco_IsIdle(XCarrier_nco *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCarrier_nco_IsReady(XCarrier_nco *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCarrier_nco_EnableAutoRestart(XCarrier_nco *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XCarrier_nco_DisableAutoRestart(XCarrier_nco *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_AP_CTRL, 0);
}

void XCarrier_nco_Set_num_samples(XCarrier_nco *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_NUM_SAMPLES_DATA, Data);
}

u32 XCarrier_nco_Get_num_samples(XCarrier_nco *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_NUM_SAMPLES_DATA);
    return Data;
}

void XCarrier_nco_Set_phase_inc(XCarrier_nco *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_PHASE_INC_DATA, Data);
}

u32 XCarrier_nco_Get_phase_inc(XCarrier_nco *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_PHASE_INC_DATA);
    return Data;
}

void XCarrier_nco_Set_initial_phase(XCarrier_nco *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_INITIAL_PHASE_DATA, Data);
}

u32 XCarrier_nco_Get_initial_phase(XCarrier_nco *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_INITIAL_PHASE_DATA);
    return Data;
}

void XCarrier_nco_Set_signal_i(XCarrier_nco *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_SIGNAL_I_DATA, (u32)(Data));
    XCarrier_nco_WriteReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_SIGNAL_I_DATA + 4, (u32)(Data >> 32));
}

u64 XCarrier_nco_Get_signal_i(XCarrier_nco *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_SIGNAL_I_DATA);
    Data += (u64)XCarrier_nco_ReadReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_SIGNAL_I_DATA + 4) << 32;
    return Data;
}

void XCarrier_nco_Set_signal_q(XCarrier_nco *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_SIGNAL_Q_DATA, (u32)(Data));
    XCarrier_nco_WriteReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_SIGNAL_Q_DATA + 4, (u32)(Data >> 32));
}

u64 XCarrier_nco_Get_signal_q(XCarrier_nco *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_SIGNAL_Q_DATA);
    Data += (u64)XCarrier_nco_ReadReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_SIGNAL_Q_DATA + 4) << 32;
    return Data;
}

void XCarrier_nco_Set_wiped_i(XCarrier_nco *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_WIPED_I_DATA, (u32)(Data));
    XCarrier_nco_WriteReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_WIPED_I_DATA + 4, (u32)(Data >> 32));
}

u64 XCarrier_nco_Get_wiped_i(XCarrier_nco *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_WIPED_I_DATA);
    Data += (u64)XCarrier_nco_ReadReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_WIPED_I_DATA + 4) << 32;
    return Data;
}

void XCarrier_nco_Set_wiped_q(XCarrier_nco *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_WIPED_Q_DATA, (u32)(Data));
    XCarrier_nco_WriteReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_WIPED_Q_DATA + 4, (u32)(Data >> 32));
}

u64 XCarrier_nco_Get_wiped_q(XCarrier_nco *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCarrier_nco_ReadReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_WIPED_Q_DATA);
    Data += (u64)XCarrier_nco_ReadReg(InstancePtr->Control_r_BaseAddress, XCARRIER_NCO_CONTROL_R_ADDR_WIPED_Q_DATA + 4) << 32;
    return Data;
}

void XCarrier_nco_InterruptGlobalEnable(XCarrier_nco *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_GIE, 1);
}

void XCarrier_nco_InterruptGlobalDisable(XCarrier_nco *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_GIE, 0);
}

void XCarrier_nco_InterruptEnable(XCarrier_nco *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_IER);
    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_IER, Register | Mask);
}

void XCarrier_nco_InterruptDisable(XCarrier_nco *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_IER);
    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_IER, Register & (~Mask));
}

void XCarrier_nco_InterruptClear(XCarrier_nco *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCarrier_nco_WriteReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_ISR, Mask);
}

u32 XCarrier_nco_InterruptGetEnabled(XCarrier_nco *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_IER);
}

u32 XCarrier_nco_InterruptGetStatus(XCarrier_nco *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCarrier_nco_ReadReg(InstancePtr->Control_BaseAddress, XCARRIER_NCO_CONTROL_ADDR_ISR);
}


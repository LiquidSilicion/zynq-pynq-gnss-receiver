// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xcarrier_nco.h"

extern XCarrier_nco_Config XCarrier_nco_ConfigTable[];

#ifdef SDT
XCarrier_nco_Config *XCarrier_nco_LookupConfig(UINTPTR BaseAddress) {
	XCarrier_nco_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XCarrier_nco_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XCarrier_nco_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XCarrier_nco_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCarrier_nco_Initialize(XCarrier_nco *InstancePtr, UINTPTR BaseAddress) {
	XCarrier_nco_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCarrier_nco_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCarrier_nco_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XCarrier_nco_Config *XCarrier_nco_LookupConfig(u16 DeviceId) {
	XCarrier_nco_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCARRIER_NCO_NUM_INSTANCES; Index++) {
		if (XCarrier_nco_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XCarrier_nco_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XCarrier_nco_Initialize(XCarrier_nco *InstancePtr, u16 DeviceId) {
	XCarrier_nco_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XCarrier_nco_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XCarrier_nco_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif


// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XCARRIER_NCO_H
#define XCARRIER_NCO_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcarrier_nco_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XCarrier_nco_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XCarrier_nco;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCarrier_nco_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCarrier_nco_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCarrier_nco_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCarrier_nco_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XCarrier_nco_Initialize(XCarrier_nco *InstancePtr, UINTPTR BaseAddress);
XCarrier_nco_Config* XCarrier_nco_LookupConfig(UINTPTR BaseAddress);
#else
int XCarrier_nco_Initialize(XCarrier_nco *InstancePtr, u16 DeviceId);
XCarrier_nco_Config* XCarrier_nco_LookupConfig(u16 DeviceId);
#endif
int XCarrier_nco_CfgInitialize(XCarrier_nco *InstancePtr, XCarrier_nco_Config *ConfigPtr);
#else
int XCarrier_nco_Initialize(XCarrier_nco *InstancePtr, const char* InstanceName);
int XCarrier_nco_Release(XCarrier_nco *InstancePtr);
#endif

void XCarrier_nco_Start(XCarrier_nco *InstancePtr);
u32 XCarrier_nco_IsDone(XCarrier_nco *InstancePtr);
u32 XCarrier_nco_IsIdle(XCarrier_nco *InstancePtr);
u32 XCarrier_nco_IsReady(XCarrier_nco *InstancePtr);
void XCarrier_nco_EnableAutoRestart(XCarrier_nco *InstancePtr);
void XCarrier_nco_DisableAutoRestart(XCarrier_nco *InstancePtr);

void XCarrier_nco_Set_num_samples(XCarrier_nco *InstancePtr, u32 Data);
u32 XCarrier_nco_Get_num_samples(XCarrier_nco *InstancePtr);
void XCarrier_nco_Set_phase_inc(XCarrier_nco *InstancePtr, u32 Data);
u32 XCarrier_nco_Get_phase_inc(XCarrier_nco *InstancePtr);
void XCarrier_nco_Set_initial_phase(XCarrier_nco *InstancePtr, u32 Data);
u32 XCarrier_nco_Get_initial_phase(XCarrier_nco *InstancePtr);
void XCarrier_nco_Set_signal_i(XCarrier_nco *InstancePtr, u64 Data);
u64 XCarrier_nco_Get_signal_i(XCarrier_nco *InstancePtr);
void XCarrier_nco_Set_signal_q(XCarrier_nco *InstancePtr, u64 Data);
u64 XCarrier_nco_Get_signal_q(XCarrier_nco *InstancePtr);
void XCarrier_nco_Set_wiped_i(XCarrier_nco *InstancePtr, u64 Data);
u64 XCarrier_nco_Get_wiped_i(XCarrier_nco *InstancePtr);
void XCarrier_nco_Set_wiped_q(XCarrier_nco *InstancePtr, u64 Data);
u64 XCarrier_nco_Get_wiped_q(XCarrier_nco *InstancePtr);

void XCarrier_nco_InterruptGlobalEnable(XCarrier_nco *InstancePtr);
void XCarrier_nco_InterruptGlobalDisable(XCarrier_nco *InstancePtr);
void XCarrier_nco_InterruptEnable(XCarrier_nco *InstancePtr, u32 Mask);
void XCarrier_nco_InterruptDisable(XCarrier_nco *InstancePtr, u32 Mask);
void XCarrier_nco_InterruptClear(XCarrier_nco *InstancePtr, u32 Mask);
u32 XCarrier_nco_InterruptGetEnabled(XCarrier_nco *InstancePtr);
u32 XCarrier_nco_InterruptGetStatus(XCarrier_nco *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

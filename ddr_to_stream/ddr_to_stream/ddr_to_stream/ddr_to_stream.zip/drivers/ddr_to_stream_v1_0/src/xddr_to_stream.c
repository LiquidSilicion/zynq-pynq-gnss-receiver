// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xddr_to_stream.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDdr_to_stream_CfgInitialize(XDdr_to_stream *InstancePtr, XDdr_to_stream_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDdr_to_stream_Start(XDdr_to_stream *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_AP_CTRL) & 0x80;
    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDdr_to_stream_IsDone(XDdr_to_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDdr_to_stream_IsIdle(XDdr_to_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDdr_to_stream_IsReady(XDdr_to_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDdr_to_stream_EnableAutoRestart(XDdr_to_stream *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XDdr_to_stream_DisableAutoRestart(XDdr_to_stream *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_AP_CTRL, 0);
}

void XDdr_to_stream_Set_num_samples(XDdr_to_stream *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_NUM_SAMPLES_DATA, Data);
}

u32 XDdr_to_stream_Get_num_samples(XDdr_to_stream *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_NUM_SAMPLES_DATA);
    return Data;
}

void XDdr_to_stream_Set_data_real(XDdr_to_stream *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDdr_to_stream_WriteReg(InstancePtr->Control_r_BaseAddress, XDDR_TO_STREAM_CONTROL_R_ADDR_DATA_REAL_DATA, (u32)(Data));
    XDdr_to_stream_WriteReg(InstancePtr->Control_r_BaseAddress, XDDR_TO_STREAM_CONTROL_R_ADDR_DATA_REAL_DATA + 4, (u32)(Data >> 32));
}

u64 XDdr_to_stream_Get_data_real(XDdr_to_stream *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDdr_to_stream_ReadReg(InstancePtr->Control_r_BaseAddress, XDDR_TO_STREAM_CONTROL_R_ADDR_DATA_REAL_DATA);
    Data += (u64)XDdr_to_stream_ReadReg(InstancePtr->Control_r_BaseAddress, XDDR_TO_STREAM_CONTROL_R_ADDR_DATA_REAL_DATA + 4) << 32;
    return Data;
}

void XDdr_to_stream_Set_data_imag(XDdr_to_stream *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDdr_to_stream_WriteReg(InstancePtr->Control_r_BaseAddress, XDDR_TO_STREAM_CONTROL_R_ADDR_DATA_IMAG_DATA, (u32)(Data));
    XDdr_to_stream_WriteReg(InstancePtr->Control_r_BaseAddress, XDDR_TO_STREAM_CONTROL_R_ADDR_DATA_IMAG_DATA + 4, (u32)(Data >> 32));
}

u64 XDdr_to_stream_Get_data_imag(XDdr_to_stream *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDdr_to_stream_ReadReg(InstancePtr->Control_r_BaseAddress, XDDR_TO_STREAM_CONTROL_R_ADDR_DATA_IMAG_DATA);
    Data += (u64)XDdr_to_stream_ReadReg(InstancePtr->Control_r_BaseAddress, XDDR_TO_STREAM_CONTROL_R_ADDR_DATA_IMAG_DATA + 4) << 32;
    return Data;
}

void XDdr_to_stream_InterruptGlobalEnable(XDdr_to_stream *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_GIE, 1);
}

void XDdr_to_stream_InterruptGlobalDisable(XDdr_to_stream *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_GIE, 0);
}

void XDdr_to_stream_InterruptEnable(XDdr_to_stream *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_IER);
    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_IER, Register | Mask);
}

void XDdr_to_stream_InterruptDisable(XDdr_to_stream *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_IER);
    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_IER, Register & (~Mask));
}

void XDdr_to_stream_InterruptClear(XDdr_to_stream *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDdr_to_stream_WriteReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_ISR, Mask);
}

u32 XDdr_to_stream_InterruptGetEnabled(XDdr_to_stream *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_IER);
}

u32 XDdr_to_stream_InterruptGetStatus(XDdr_to_stream *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDdr_to_stream_ReadReg(InstancePtr->Control_BaseAddress, XDDR_TO_STREAM_CONTROL_ADDR_ISR);
}


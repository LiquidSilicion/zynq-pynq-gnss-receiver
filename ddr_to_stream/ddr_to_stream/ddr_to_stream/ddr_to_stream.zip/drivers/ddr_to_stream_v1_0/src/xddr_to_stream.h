// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XDDR_TO_STREAM_H
#define XDDR_TO_STREAM_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xddr_to_stream_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XDdr_to_stream_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XDdr_to_stream;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XDdr_to_stream_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XDdr_to_stream_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XDdr_to_stream_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XDdr_to_stream_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XDdr_to_stream_Initialize(XDdr_to_stream *InstancePtr, UINTPTR BaseAddress);
XDdr_to_stream_Config* XDdr_to_stream_LookupConfig(UINTPTR BaseAddress);
#else
int XDdr_to_stream_Initialize(XDdr_to_stream *InstancePtr, u16 DeviceId);
XDdr_to_stream_Config* XDdr_to_stream_LookupConfig(u16 DeviceId);
#endif
int XDdr_to_stream_CfgInitialize(XDdr_to_stream *InstancePtr, XDdr_to_stream_Config *ConfigPtr);
#else
int XDdr_to_stream_Initialize(XDdr_to_stream *InstancePtr, const char* InstanceName);
int XDdr_to_stream_Release(XDdr_to_stream *InstancePtr);
#endif

void XDdr_to_stream_Start(XDdr_to_stream *InstancePtr);
u32 XDdr_to_stream_IsDone(XDdr_to_stream *InstancePtr);
u32 XDdr_to_stream_IsIdle(XDdr_to_stream *InstancePtr);
u32 XDdr_to_stream_IsReady(XDdr_to_stream *InstancePtr);
void XDdr_to_stream_EnableAutoRestart(XDdr_to_stream *InstancePtr);
void XDdr_to_stream_DisableAutoRestart(XDdr_to_stream *InstancePtr);

void XDdr_to_stream_Set_num_samples(XDdr_to_stream *InstancePtr, u32 Data);
u32 XDdr_to_stream_Get_num_samples(XDdr_to_stream *InstancePtr);
void XDdr_to_stream_Set_data_real(XDdr_to_stream *InstancePtr, u64 Data);
u64 XDdr_to_stream_Get_data_real(XDdr_to_stream *InstancePtr);
void XDdr_to_stream_Set_data_imag(XDdr_to_stream *InstancePtr, u64 Data);
u64 XDdr_to_stream_Get_data_imag(XDdr_to_stream *InstancePtr);

void XDdr_to_stream_InterruptGlobalEnable(XDdr_to_stream *InstancePtr);
void XDdr_to_stream_InterruptGlobalDisable(XDdr_to_stream *InstancePtr);
void XDdr_to_stream_InterruptEnable(XDdr_to_stream *InstancePtr, u32 Mask);
void XDdr_to_stream_InterruptDisable(XDdr_to_stream *InstancePtr, u32 Mask);
void XDdr_to_stream_InterruptClear(XDdr_to_stream *InstancePtr, u32 Mask);
u32 XDdr_to_stream_InterruptGetEnabled(XDdr_to_stream *InstancePtr);
u32 XDdr_to_stream_InterruptGetStatus(XDdr_to_stream *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

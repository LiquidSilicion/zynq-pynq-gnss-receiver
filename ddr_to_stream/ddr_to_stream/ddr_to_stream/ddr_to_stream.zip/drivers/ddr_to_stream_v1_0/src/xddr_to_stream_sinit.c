// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xddr_to_stream.h"

extern XDdr_to_stream_Config XDdr_to_stream_ConfigTable[];

#ifdef SDT
XDdr_to_stream_Config *XDdr_to_stream_LookupConfig(UINTPTR BaseAddress) {
	XDdr_to_stream_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XDdr_to_stream_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XDdr_to_stream_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XDdr_to_stream_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDdr_to_stream_Initialize(XDdr_to_stream *InstancePtr, UINTPTR BaseAddress) {
	XDdr_to_stream_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDdr_to_stream_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDdr_to_stream_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XDdr_to_stream_Config *XDdr_to_stream_LookupConfig(u16 DeviceId) {
	XDdr_to_stream_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDDR_TO_STREAM_NUM_INSTANCES; Index++) {
		if (XDdr_to_stream_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDdr_to_stream_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDdr_to_stream_Initialize(XDdr_to_stream *InstancePtr, u16 DeviceId) {
	XDdr_to_stream_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDdr_to_stream_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDdr_to_stream_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif


// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XCOMPLEX_MULTIPLY_H
#define XCOMPLEX_MULTIPLY_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcomplex_multiply_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XComplex_multiply_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XComplex_multiply;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XComplex_multiply_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XComplex_multiply_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XComplex_multiply_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XComplex_multiply_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XComplex_multiply_Initialize(XComplex_multiply *InstancePtr, UINTPTR BaseAddress);
XComplex_multiply_Config* XComplex_multiply_LookupConfig(UINTPTR BaseAddress);
#else
int XComplex_multiply_Initialize(XComplex_multiply *InstancePtr, u16 DeviceId);
XComplex_multiply_Config* XComplex_multiply_LookupConfig(u16 DeviceId);
#endif
int XComplex_multiply_CfgInitialize(XComplex_multiply *InstancePtr, XComplex_multiply_Config *ConfigPtr);
#else
int XComplex_multiply_Initialize(XComplex_multiply *InstancePtr, const char* InstanceName);
int XComplex_multiply_Release(XComplex_multiply *InstancePtr);
#endif

void XComplex_multiply_Start(XComplex_multiply *InstancePtr);
u32 XComplex_multiply_IsDone(XComplex_multiply *InstancePtr);
u32 XComplex_multiply_IsIdle(XComplex_multiply *InstancePtr);
u32 XComplex_multiply_IsReady(XComplex_multiply *InstancePtr);
void XComplex_multiply_EnableAutoRestart(XComplex_multiply *InstancePtr);
void XComplex_multiply_DisableAutoRestart(XComplex_multiply *InstancePtr);

void XComplex_multiply_Set_num_samples(XComplex_multiply *InstancePtr, u32 Data);
u32 XComplex_multiply_Get_num_samples(XComplex_multiply *InstancePtr);

void XComplex_multiply_InterruptGlobalEnable(XComplex_multiply *InstancePtr);
void XComplex_multiply_InterruptGlobalDisable(XComplex_multiply *InstancePtr);
void XComplex_multiply_InterruptEnable(XComplex_multiply *InstancePtr, u32 Mask);
void XComplex_multiply_InterruptDisable(XComplex_multiply *InstancePtr, u32 Mask);
void XComplex_multiply_InterruptClear(XComplex_multiply *InstancePtr, u32 Mask);
u32 XComplex_multiply_InterruptGetEnabled(XComplex_multiply *InstancePtr);
u32 XComplex_multiply_InterruptGetStatus(XComplex_multiply *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XCOMPLEX_CONJUGATE_H
#define XCOMPLEX_CONJUGATE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcomplex_conjugate_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XComplex_conjugate_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XComplex_conjugate;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XComplex_conjugate_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XComplex_conjugate_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XComplex_conjugate_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XComplex_conjugate_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XComplex_conjugate_Initialize(XComplex_conjugate *InstancePtr, UINTPTR BaseAddress);
XComplex_conjugate_Config* XComplex_conjugate_LookupConfig(UINTPTR BaseAddress);
#else
int XComplex_conjugate_Initialize(XComplex_conjugate *InstancePtr, u16 DeviceId);
XComplex_conjugate_Config* XComplex_conjugate_LookupConfig(u16 DeviceId);
#endif
int XComplex_conjugate_CfgInitialize(XComplex_conjugate *InstancePtr, XComplex_conjugate_Config *ConfigPtr);
#else
int XComplex_conjugate_Initialize(XComplex_conjugate *InstancePtr, const char* InstanceName);
int XComplex_conjugate_Release(XComplex_conjugate *InstancePtr);
#endif

void XComplex_conjugate_Start(XComplex_conjugate *InstancePtr);
u32 XComplex_conjugate_IsDone(XComplex_conjugate *InstancePtr);
u32 XComplex_conjugate_IsIdle(XComplex_conjugate *InstancePtr);
u32 XComplex_conjugate_IsReady(XComplex_conjugate *InstancePtr);
void XComplex_conjugate_EnableAutoRestart(XComplex_conjugate *InstancePtr);
void XComplex_conjugate_DisableAutoRestart(XComplex_conjugate *InstancePtr);

void XComplex_conjugate_Set_num_samples(XComplex_conjugate *InstancePtr, u32 Data);
u32 XComplex_conjugate_Get_num_samples(XComplex_conjugate *InstancePtr);

void XComplex_conjugate_InterruptGlobalEnable(XComplex_conjugate *InstancePtr);
void XComplex_conjugate_InterruptGlobalDisable(XComplex_conjugate *InstancePtr);
void XComplex_conjugate_InterruptEnable(XComplex_conjugate *InstancePtr, u32 Mask);
void XComplex_conjugate_InterruptDisable(XComplex_conjugate *InstancePtr, u32 Mask);
void XComplex_conjugate_InterruptClear(XComplex_conjugate *InstancePtr, u32 Mask);
u32 XComplex_conjugate_InterruptGetEnabled(XComplex_conjugate *InstancePtr);
u32 XComplex_conjugate_InterruptGetStatus(XComplex_conjugate *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XPEAK_DETECTOR_H
#define XPEAK_DETECTOR_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xpeak_detector_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XPeak_detector_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XPeak_detector;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XPeak_detector_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XPeak_detector_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XPeak_detector_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XPeak_detector_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XPeak_detector_Initialize(XPeak_detector *InstancePtr, UINTPTR BaseAddress);
XPeak_detector_Config* XPeak_detector_LookupConfig(UINTPTR BaseAddress);
#else
int XPeak_detector_Initialize(XPeak_detector *InstancePtr, u16 DeviceId);
XPeak_detector_Config* XPeak_detector_LookupConfig(u16 DeviceId);
#endif
int XPeak_detector_CfgInitialize(XPeak_detector *InstancePtr, XPeak_detector_Config *ConfigPtr);
#else
int XPeak_detector_Initialize(XPeak_detector *InstancePtr, const char* InstanceName);
int XPeak_detector_Release(XPeak_detector *InstancePtr);
#endif

void XPeak_detector_Start(XPeak_detector *InstancePtr);
u32 XPeak_detector_IsDone(XPeak_detector *InstancePtr);
u32 XPeak_detector_IsIdle(XPeak_detector *InstancePtr);
u32 XPeak_detector_IsReady(XPeak_detector *InstancePtr);
void XPeak_detector_EnableAutoRestart(XPeak_detector *InstancePtr);
void XPeak_detector_DisableAutoRestart(XPeak_detector *InstancePtr);

void XPeak_detector_Set_num_samples(XPeak_detector *InstancePtr, u32 Data);
u32 XPeak_detector_Get_num_samples(XPeak_detector *InstancePtr);
u32 XPeak_detector_Get_peak_power(XPeak_detector *InstancePtr);
u32 XPeak_detector_Get_peak_power_vld(XPeak_detector *InstancePtr);
u32 XPeak_detector_Get_peak_index(XPeak_detector *InstancePtr);
u32 XPeak_detector_Get_peak_index_vld(XPeak_detector *InstancePtr);

void XPeak_detector_InterruptGlobalEnable(XPeak_detector *InstancePtr);
void XPeak_detector_InterruptGlobalDisable(XPeak_detector *InstancePtr);
void XPeak_detector_InterruptEnable(XPeak_detector *InstancePtr, u32 Mask);
void XPeak_detector_InterruptDisable(XPeak_detector *InstancePtr, u32 Mask);
void XPeak_detector_InterruptClear(XPeak_detector *InstancePtr, u32 Mask);
u32 XPeak_detector_InterruptGetEnabled(XPeak_detector *InstancePtr);
u32 XPeak_detector_InterruptGetStatus(XPeak_detector *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

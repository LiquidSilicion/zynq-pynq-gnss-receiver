// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xpeak_detector.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPeak_detector_CfgInitialize(XPeak_detector *InstancePtr, XPeak_detector_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPeak_detector_Start(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_AP_CTRL) & 0x80;
    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XPeak_detector_IsDone(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XPeak_detector_IsIdle(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XPeak_detector_IsReady(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XPeak_detector_EnableAutoRestart(XPeak_detector *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XPeak_detector_DisableAutoRestart(XPeak_detector *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_AP_CTRL, 0);
}

void XPeak_detector_Set_num_samples(XPeak_detector *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_NUM_SAMPLES_DATA, Data);
}

u32 XPeak_detector_Get_num_samples(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_NUM_SAMPLES_DATA);
    return Data;
}

u32 XPeak_detector_Get_peak_power(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_PEAK_POWER_DATA);
    return Data;
}

u32 XPeak_detector_Get_peak_power_vld(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_PEAK_POWER_CTRL);
    return Data & 0x1;
}

u32 XPeak_detector_Get_peak_index(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_PEAK_INDEX_DATA);
    return Data;
}

u32 XPeak_detector_Get_peak_index_vld(XPeak_detector *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_PEAK_INDEX_CTRL);
    return Data & 0x1;
}

void XPeak_detector_InterruptGlobalEnable(XPeak_detector *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_GIE, 1);
}

void XPeak_detector_InterruptGlobalDisable(XPeak_detector *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_GIE, 0);
}

void XPeak_detector_InterruptEnable(XPeak_detector *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_IER);
    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_IER, Register | Mask);
}

void XPeak_detector_InterruptDisable(XPeak_detector *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_IER);
    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_IER, Register & (~Mask));
}

void XPeak_detector_InterruptClear(XPeak_detector *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPeak_detector_WriteReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_ISR, Mask);
}

u32 XPeak_detector_InterruptGetEnabled(XPeak_detector *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_IER);
}

u32 XPeak_detector_InterruptGetStatus(XPeak_detector *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPeak_detector_ReadReg(InstancePtr->Control_BaseAddress, XPEAK_DETECTOR_CONTROL_ADDR_ISR);
}


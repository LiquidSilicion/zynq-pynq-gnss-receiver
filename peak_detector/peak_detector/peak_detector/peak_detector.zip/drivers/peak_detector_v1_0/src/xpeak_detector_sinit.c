// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xpeak_detector.h"

extern XPeak_detector_Config XPeak_detector_ConfigTable[];

#ifdef SDT
XPeak_detector_Config *XPeak_detector_LookupConfig(UINTPTR BaseAddress) {
	XPeak_detector_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XPeak_detector_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XPeak_detector_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XPeak_detector_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XPeak_detector_Initialize(XPeak_detector *InstancePtr, UINTPTR BaseAddress) {
	XPeak_detector_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XPeak_detector_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XPeak_detector_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XPeak_detector_Config *XPeak_detector_LookupConfig(u16 DeviceId) {
	XPeak_detector_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XPEAK_DETECTOR_NUM_INSTANCES; Index++) {
		if (XPeak_detector_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XPeak_detector_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XPeak_detector_Initialize(XPeak_detector *InstancePtr, u16 DeviceId) {
	XPeak_detector_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XPeak_detector_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XPeak_detector_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

